#!/usr/bin/env python
import sys
import gc

sys.path.insert(0, "../library/ext")

import library.digi_ElementTree as ET
from library.helpers import iso_date

sample_q = []

def addr2iDigiDataLabel(addr_tuple):
    if addr_tuple[0][-1] == '!': #XBee address
        # [00:11:22:33:44:aa:bb:cc:dd]! -> XBee_AABBCCDD
        return "XBee_" + ''.join(addr_tuple[0].split(":")[4:])[:-2].upper()
    elif '.' in addr_tuple[0]: #IPv4 address
        # 192.168.0.1 -> IPv4_192_168_0_1
        return "IPv4_" + '_'.join(addr_tuple[0].split('.'))
    elif ':' in addr_tuple[0]: #IPv6 address
        # FE80::0:1 -> IPv6_FE80__0_1
        return "IPv6_" + '_'.join(addr_tuple[0].split(':'))
    else:
        # error
        raise Exception("Unrecognized addr: %s" % str(addr_tuple))

def format_doc():
    doc = ET.Element("idigi_data")
    doc.set("compact", "True")

    for sample in sample_q:
        elem = ET.Element("sample")
        map(lambda k: elem.set(k, sample[k]), sample.keys())
        doc.append(elem)

    return ET.ElementTree(doc).writestring()

def sample_add(name, value, unit, timestamp):
        sample = { "name": name, "value": value,
                   "unit": unit, "timestamp": timestamp }

        sample_q.append(sample)

def main():
	addr = ("00:11:22:33:44:55:66:77!", 0xe8, 0xc104, 0x11)
	io_pin = "DIO1"
	value = "True"
	unit = "bool"
	sample_add(addr2iDigiDataLabel(addr) + "." + io_pin, value, unit,
                             iso_date(None, True))

	print repr(format_doc())

if __name__ == "__main__":
    ret = main()
    sys.exit(ret)